package com.dasima.drawrun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DrawrunApplicationTests {

	@Test
	void contextLoads() {
	}

}
