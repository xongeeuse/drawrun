package com.dasima.drawrun.global.security;

public enum TokenType {
  ACCESS, REFRESH
}
