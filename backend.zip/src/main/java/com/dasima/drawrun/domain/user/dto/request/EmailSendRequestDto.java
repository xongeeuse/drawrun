package com.dasima.drawrun.domain.user.dto.request;

import lombok.Data;

@Data
public class EmailSendRequestDto {
    private String email;
}
