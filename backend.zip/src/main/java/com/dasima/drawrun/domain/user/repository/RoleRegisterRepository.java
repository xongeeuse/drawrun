package com.dasima.drawrun.domain.user.repository;

import com.dasima.drawrun.domain.user.entity.RoleRegister;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRegisterRepository extends JpaRepository<RoleRegister, Integer> {

}
