package com.dasima.drawrun.domain.course.service;

import com.dasima.drawrun.domain.course.dto.CourseSaveRequest;
import org.springframework.stereotype.Service;

@Service
public class CourseServiceImpl implements CourseService{
    public int save(CourseSaveRequest dto){
        // 지역을 가지고 온다.

    }
}
