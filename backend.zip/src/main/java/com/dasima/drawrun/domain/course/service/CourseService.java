package com.dasima.drawrun.domain.course.service;

public interface CourseService {
}
