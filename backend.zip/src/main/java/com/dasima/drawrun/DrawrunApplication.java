package com.dasima.drawrun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DrawrunApplication {

	public static void main(String[] args) {
		SpringApplication.run(DrawrunApplication.class, args);
	}

}
