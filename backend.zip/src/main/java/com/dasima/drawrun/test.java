package com.dasima.drawrun;

public class test {
    public static void main(String[] args) {
        System.out.println("Hello World");
        System.out.println("왜 안됨??");
        System.out.println("제발 되라");
        System.out.println("이제는 되겠지?");
        System.out.println("이제는 되라진짜ㅋㅋ");
        System.out.println("제발 ㅠㅠ");
        System.out.println("Docker 아이디 설정 잘못함 ㅋㅋㅋㅋㅋ ㅠㅠ");
        System.out.println("아 3시간째 뭐하고있노;;");
        System.out.println("mysql만 되면 완성ㅋ");
        System.out.println("갑자기 왜이럼?");
        System.out.println("이미지가 겹치는걸 해결하자ㅇㄴㅁㅇㄴㅁㅇㄹㅇㄹㅇㄴㄹㅇㄴㄴㅁㄴ");
    }
}
